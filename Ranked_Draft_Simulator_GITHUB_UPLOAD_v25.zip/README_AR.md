# Ranked Draft Simulator v25 — Android

هذا المشروع يحتوي على لعبة Ranked Draft Simulator v25 داخل WebView كتطبيق Android.

## بناء APK تلقائياً
1. ارفع هذا المجلد إلى GitHub كمستودع جديد.
2. افتح تبويب Actions.
3. شغّل workflow باسم **Build Android APK**.
4. بعد انتهاء البناء، افتح Artifacts وحمّل `Ranked-Draft-Simulator-APK`.
5. فك الضغط وستجد `app-debug.apk` جاهزاً للتثبيت.

لا تحتاج إلى تثبيت Android Studio على الهاتف إذا استخدمت GitHub Actions.
